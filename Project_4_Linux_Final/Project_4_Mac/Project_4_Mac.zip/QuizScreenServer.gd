extends Control


@export_file("*.json") var database_file = "res://FakeDatabase.json"
@export var turn_delay_in_seconds = 5.0

@onready var database = JSON.parse_string(FileAccess.open(database_file,FileAccess.READ).get_as_text())
@onready var quiz_panel = $QuizPanel
@onready var timer = $Timer
@onready var wait_label = $WaitLabel
var player_scores = {}


func _ready():
	timer.start(3.0)
	await(timer.timeout)
	generate_new_question()
	for user in GameData.logged_users.keys():
		player_scores[user] = 0
	rpc("update_player_scores", player_scores)
	print("Initial player scores sent:", player_scores)

@rpc("any_peer")
func answered(user):
	if user in player_scores:
		player_scores[user] += 1
	else:
		player_scores[user] = 1  # Just in case
	rpc("update_player_scores", player_scores)
	print("Updated player scores sent:", player_scores)
	quiz_panel.rpc("update_winner", database[user]["name"])
	timer.start(turn_delay_in_seconds)
	wait_label.rpc("wait", turn_delay_in_seconds)
	


@rpc("any_peer")
func missed(user):
	rpc("update_player_scores", player_scores)
	quiz_panel.rpc("player_missed", database[user]["name"])
	timer.start(turn_delay_in_seconds)
	wait_label.rpc("wait", turn_delay_in_seconds)


func _on_timer_timeout():
	generate_new_question()


func generate_new_question():
	var max_index = quiz_panel.available_questions.size() -2
	var question_index = randi_range(0, max_index)
	quiz_panel.rpc("update_question", question_index)
	quiz_panel.update_question(question_index)

