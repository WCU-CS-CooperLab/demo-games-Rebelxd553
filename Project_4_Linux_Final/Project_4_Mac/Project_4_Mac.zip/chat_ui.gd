extends Control

signal send_message(message: String)

@onready var chat_label = $VBoxContainer/ScrollContainer/ChatLabel
@onready var chat_scroll = $VBoxContainer/ScrollContainer
@onready var input_line_edit = $VBoxContainer/ChatInput

func _ready():
	input_line_edit.text_submitted.connect(_on_chat_input_text_submitted)
	input_line_edit.grab_focus()

	
func _on_chat_input_text_submitted(new_text):
	if new_text.strip_edges() != "":
		emit_signal("send_message", new_text.strip_edges())
		input_line_edit.clear()


func display_message(sender_name: String, message: String):
	print("Displaying message from", sender_name, ":", message)
	chat_label.text += "%s: %s\n" % [sender_name, message]
	await get_tree().process_frame  # Ensure UI updates
	chat_scroll.scroll_vertical = chat_scroll.get_v_scrollbar().max_value

