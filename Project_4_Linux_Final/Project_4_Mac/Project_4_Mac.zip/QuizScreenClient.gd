extends Control

var player_scores = {}
@onready var scores_label = $PlayerStatusPanel/ScoresLabel


func _ready():
	# ... [Existing code] ...
	print("ScoresLabel Node:", scores_label)
	$QuizPanel.game_over.connect(_on_game_over)
	$QuizPanel.answered.connect(_on_quiz_panel_answered)
	scores_label.text = "Player Scores:\n"

func _on_game_over():
	print("Received game over signal from QuizPanel")
	get_tree().change_scene_to_file("res://game_over.tscn")

func _on_quiz_panel_answered(is_answer_correct):
	var server_peer_id = 1
	var current_user = AuthenticationCredentials.user
	if not current_user:
		print("Error: AuthenticationCredentials.user is not set.")
		return
		
	if is_answer_correct:
		print("%s answered correctly." % current_user)
		rpc_id(
			server_peer_id,
			"answered",
			current_user
			)
	else:
		print("%s missed the answer." % current_user)
		rpc_id(
			server_peer_id,
			"missed",
			current_user
			)


@rpc
func answered(user):
	pass


@rpc
func missed(user):
	pass

@rpc("call_remote", "authority")
func update_player_scores(new_scores):
	print("Received updated scores from server:", new_scores)
	player_scores = new_scores
	update_player_scores_ui()
	
func update_player_scores_ui():
	# Initialize the scores_text with a header
	var scores_text = "Player Scores:\n\n"
	
	# Sort players by score in descending order
	var sorted_players = player_scores.keys()
	sorted_players.sort_custom(self, "_compare_scores")
	
	# Append each player's name and score to the scores_text
	for user in sorted_players:
		var score = player_scores[user]
		scores_text += "%s: %d\n" % [user, score]
	
	# Update the ScoresLabel's text with the compiled scores
	scores_label.text = scores_text
	print("Updated ScoresLabel text:", scores_text)



func _compare_scores(a, b):
	return player_scores[b] - player_scores[a]

