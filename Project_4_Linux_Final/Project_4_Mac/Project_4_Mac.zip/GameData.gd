extends Node

var logged_users = {}
