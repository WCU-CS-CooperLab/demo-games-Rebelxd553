extends Control


const PORT = 3000

@export var database_file_path = "res://FakeDatabase.json"
@export_file("*.tscn") var quiz_screen_scene_path = "res://QuizScreenServer.tscn"
@onready var start_button = $StartButton


var peer = ENetMultiplayerPeer.new()
var database = {}
var logged_users = {}


func _ready():
	peer.create_server(PORT)
	multiplayer.multiplayer_peer = peer
	load_database()
	start_button.grab_focus()
	start_button.connect("pressed", Callable(self, "_on_start_button_pressed"))
	print("Server peer ID:", multiplayer.get_unique_id())

func load_database(path_to_database_file = database_file_path):
	var file = FileAccess.open(path_to_database_file, FileAccess.READ)
	var file_content = file.get_as_text()
	database = JSON.parse_string(file_content)


@rpc("any_peer", "call_remote")
func authenticate_player(user, password):
	var peer_id = multiplayer.get_remote_sender_id()
	
	if not user in database:
		rpc_id(peer_id, "authentication_failed", "User doesn't exist")
	elif not database[user]['password'] == password:
		rpc_id(peer_id, "authentication_failed", "Password doesn't match")
	elif user in logged_users:
		rpc_id(peer_id, "authentication_failed", "User is already logged")
	elif database[user]['password'] == password:
		var token = randi()
		logged_users[user] = token
		GameData.logged_users[user] = token
		rpc_id(peer_id, "authentication_succeed", token)
		rpc("clear_logged_players")
		for logged_user in logged_users.keys():
			rpc("add_logged_player", database[logged_user]['name'])

@rpc("any_peer")
func broadcast_chat_message(sender_name: String, message: String):
	# Get all connected peer IDs excluding the server's own ID
	var client_peer_ids = []
	for peer_id in multiplayer.get_peers():
		if peer_id != multiplayer.get_unique_id():
			client_peer_ids.append(peer_id)
	# Send the 'receive_chat_message' RPC to all connected clients
	rpc("receive_chat_message", [sender_name, message], {
		"targets": client_peer_ids
	})


@rpc("any_peer", "call_remote")
func start_game():
	rpc("start_game")
	get_tree().change_scene_to_file(quiz_screen_scene_path)


@rpc
func authentication_failed(error_message):
	pass


@rpc
func authentication_succeed(session_token):
	pass


@rpc
func add_logged_player(player_name):
	pass


@rpc
func clear_logged_players():
	pass


func _on_start_button_pressed():
	start_game()
