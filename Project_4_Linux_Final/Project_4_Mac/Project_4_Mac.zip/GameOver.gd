extends Control

@onready var gameover_label = $GameOverLabel
@onready var return_button = $ReturnButton

func _ready():
	gameover_label.text = "Game Over"

func _on_return_button_pressed():
	get_tree().change_scene_to_file("res://main_menu.tscn")
